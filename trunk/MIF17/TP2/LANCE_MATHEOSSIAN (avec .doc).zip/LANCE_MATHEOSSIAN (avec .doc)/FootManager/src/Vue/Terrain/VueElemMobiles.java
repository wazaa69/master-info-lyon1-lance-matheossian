package Vue.Terrain;

import java.awt.Graphics;

/**
 * Classe abstraite pour obliger les fils à écrire la méthode de dessin
 */

public abstract class VueElemMobiles {
    public abstract void dessiner(Graphics g);
}
