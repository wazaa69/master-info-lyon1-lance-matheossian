package ObservListe;

/**
 * Action de mise à jour après un clic sur un bouton
 */
public interface ObserveurBouton {
        public void miseAJour(String action);
}
