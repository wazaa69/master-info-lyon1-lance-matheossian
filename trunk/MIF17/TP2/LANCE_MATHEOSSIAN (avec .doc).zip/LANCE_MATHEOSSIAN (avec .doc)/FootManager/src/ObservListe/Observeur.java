package ObservListe;

/**
 * Classe simple, pour les mises à jour après notification
 */
public interface Observeur {
	public void miseAJour();
}

