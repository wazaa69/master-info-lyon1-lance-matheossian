/**
 * Classe d'exemple B
 */

#include "ClassB.hpp"
 
ClassB::ClassB(string monNom);

string ClassB::getMonNom() const;

void ClassB::setMonNom(string monNom);

double ClassB::maMethode();
