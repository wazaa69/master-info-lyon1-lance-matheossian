/**
 * Classe d'exemple A
 */

#include "ClassA.hpp"
 

ClassA::ClassA();
ClassA::~ClassA();
double ClassA::maMethode();
double ClassA::maMethode(int param1, const string param2);
double ClassA::monAutreMethode(int param1 = 0);
